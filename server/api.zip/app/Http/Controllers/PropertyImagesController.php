<?php

namespace App\Http\Controllers;

use App\Models\PropertyImages;
use Illuminate\Http\Request;

class PropertyImagesController extends Controller
{
}
