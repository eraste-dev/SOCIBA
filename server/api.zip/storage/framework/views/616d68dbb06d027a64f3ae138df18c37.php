<?php
    $title = 'Page Not Found';
    $code = 404;
?>
<?php /**PATH /opt/lampp/htdocs/www/sociba/others/server/resources/views/errors/404.blade.php ENDPATH**/ ?>